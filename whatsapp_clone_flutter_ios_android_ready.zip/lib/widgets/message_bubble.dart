import 'package:flutter/material.dart';

class MessageBubble extends StatefulWidget {
  final String message;

  MessageBubble({required this.message});

  @override
  _MessageBubbleState createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<MessageBubble> {
  String? reaction;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(widget.message),
      subtitle: reaction != null ? Text("Reaction: $reaction") : null,
      trailing: PopupMenuButton<String>(
        onSelected: (value) => setState(() => reaction = value),
        itemBuilder: (context) => [
          PopupMenuItem(value: "❤️", child: Text("❤️")),
          PopupMenuItem(value: "😂", child: Text("😂")),
          PopupMenuItem(value: "👍", child: Text("👍")),
        ],
      ),
    );
  }
}
