import 'package:flutter/material.dart';

final ThemeData lightTheme = ThemeData.light().copyWith(
  primaryColor: Colors.green,
  scaffoldBackgroundColor: Colors.white,
  textTheme: TextTheme(bodyText2: TextStyle(color: Colors.black)),
);
