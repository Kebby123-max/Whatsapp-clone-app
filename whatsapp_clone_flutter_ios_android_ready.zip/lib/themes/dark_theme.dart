import 'package:flutter/material.dart';

final ThemeData darkTheme = ThemeData.dark().copyWith(
  primaryColor: Colors.teal,
  scaffoldBackgroundColor: Colors.black,
  textTheme: TextTheme(bodyText2: TextStyle(color: Colors.white)),
);
