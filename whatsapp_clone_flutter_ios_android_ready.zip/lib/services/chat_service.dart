import 'package:cloud_firestore/cloud_firestore.dart';

class ChatService {
  final _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot> getChats(String userId) {
    return _db.collection('chats').doc(userId).collection('messages').orderBy('time').snapshots();
  }

  Future<void> sendMessage(String from, String to, String message) async {
    final msgData = {
      'from': from,
      'to': to,
      'message': message,
      'time': Timestamp.now(),
    };
    await _db.collection('chats').doc(from).collection('messages').add(msgData);
    await _db.collection('chats').doc(to).collection('messages').add(msgData);
  }
}
