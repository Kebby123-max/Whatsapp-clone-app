import 'package:cloud_firestore/cloud_firestore.dart';

class StatusService {
  final _db = FirebaseFirestore.instance;

  Future<void> postStatus(String userId, String text) async {
    await _db.collection('status').doc(userId).set({
      'status': text,
      'time': Timestamp.now(),
    });
  }

  Stream<DocumentSnapshot> getStatus(String userId) {
    return _db.collection('status').doc(userId).snapshots();
  }
}
