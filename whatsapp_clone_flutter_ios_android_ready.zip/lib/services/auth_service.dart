import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> signInWithPhone(String phoneNumber, Function(String) codeSent) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (cred) async => await _auth.signInWithCredential(cred),
      verificationFailed: (e) => throw e,
      codeSent: (verificationId, _) => codeSent(verificationId),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  Future<void> verifyCode(String code, String verificationId) async {
    final credential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: code);
    await _auth.signInWithCredential(credential);
  }

  User? get currentUser => _auth.currentUser;
}
