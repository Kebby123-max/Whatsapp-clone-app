import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController nameController = TextEditingController(text: "User Name");
  final TextEditingController statusController = TextEditingController(text: "Available");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Edit Profile")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: statusController,
              decoration: InputDecoration(labelText: "Status"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Save changes to Firebase or local storage
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Profile updated")));
              },
              child: Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}
