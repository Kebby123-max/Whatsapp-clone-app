import 'package:flutter/material.dart';

class CallScreen extends StatelessWidget {
  final bool isVideoCall;

  CallScreen({required this.isVideoCall});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isVideoCall ? "Video Call" : "Voice Call")),
      body: Center(
        child: Text(isVideoCall ? "Video call interface (Agora)" : "Voice call interface (Agora)"),
      ),
    );
  }
}
