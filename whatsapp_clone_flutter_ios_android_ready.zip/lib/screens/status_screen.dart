import 'package:flutter/material.dart';

class StatusScreen extends StatefulWidget {
  @override
  _StatusScreenState createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  final List<Map<String, String>> statuses = [
    {"name": "John", "status": "Enjoying the sunshine"},
    {"name": "Jane", "status": "Reading a book"},
    {"name": "Alex", "status": "At the gym"}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Status")),
      body: ListView.builder(
        itemCount: statuses.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(child: Text(statuses[index]['name']![0])),
            title: Text(statuses[index]['name']!),
            subtitle: Text(statuses[index]['status']!),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Logic to add a new status
        },
        child: Icon(Icons.add),
        tooltip: "Add Status",
      ),
    );
  }
}
