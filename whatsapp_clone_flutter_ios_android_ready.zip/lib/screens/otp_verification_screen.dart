import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class OTPVerificationScreen extends StatelessWidget {
  final String verificationId;
  final TextEditingController otpController = TextEditingController();

  OTPVerificationScreen({required this.verificationId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Verify OTP")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: otpController,
              decoration: InputDecoration(labelText: 'Enter OTP'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                try {
                  await AuthService().verifyCode(otpController.text, verificationId);
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Logged in successfully")));
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Verification failed")));
                }
              },
              child: Text('Verify'),
            ),
          ],
        ),
      ),
    );
  }
}
