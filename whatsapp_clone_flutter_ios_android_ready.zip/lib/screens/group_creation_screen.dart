import 'package:flutter/material.dart';

class GroupCreationScreen extends StatefulWidget {
  @override
  _GroupCreationScreenState createState() => _GroupCreationScreenState();
}

class _GroupCreationScreenState extends State<GroupCreationScreen> {
  final TextEditingController groupNameController = TextEditingController();
  List<String> members = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Group")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: groupNameController,
              decoration: InputDecoration(labelText: 'Group Name'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Logic to create group
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Group created")));
              },
              child: Text("Create Group"),
            )
          ],
        ),
      ),
    );
  }
}
