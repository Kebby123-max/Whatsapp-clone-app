import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class MediaShareScreen extends StatefulWidget {
  @override
  _MediaShareScreenState createState() => _MediaShareScreenState();
}

class _MediaShareScreenState extends State<MediaShareScreen> {
  XFile? image;

  Future<void> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      image = pickedFile;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Share Media")),
      body: Column(
        children: [
          ElevatedButton(onPressed: pickImage, child: Text("Pick Image")),
          if (image != null) Image.file(File(image!.path)),
        ],
      ),
    );
  }
}
