import 'package:flutter/material.dart';

class ContactListScreen extends StatelessWidget {
  final List<String> contacts = ["John", "Jane", "Mike", "Anna"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Contacts")),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(contacts[index]),
            onTap: () {
              // Navigate to chat screen
            },
          );
        },
      ),
    );
  }
}
